<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'mootree',
    'version' => '5.7.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/mootree',
    'repository' => 'socialengine.com',
    'title' => 'Mootree',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/mootree',
    )
  )
) ?>
