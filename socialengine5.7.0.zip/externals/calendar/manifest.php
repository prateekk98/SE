<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'calendar',
    'version' => '5.7.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/calendar',
    'repository' => 'socialengine.com',
    'title' => 'Calendar',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/calendar',
    )
  )
) ?>
