<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'chootools',
    'version' => '5.7.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/chootools',
    'repository' => 'socialengine.com',
    'title' => 'Chootools',
    'author' => 'Webligo Developments',
    'license' => 'http://www.socialengine.com/license/',
    'directories' => array(
      'externals/chootools',
    )
  )
) ?>
