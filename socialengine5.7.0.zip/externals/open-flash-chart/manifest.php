<?php return array(
  'package' => array(
    'type' => 'external',
    'name' => 'open-flash-chart',
    'version' => '5.7.0',
    'revision' => '$Revision: 9747 $',
    'path' => 'externals/open-flash-chart',
    'repository' => 'socialengine.com',
    'title' => 'Open Flash Chart Client',
    'author' => 'Webligo Developments',
    'directories' => array(
      'externals/open-flash-chart',
    ),
  )
) ?>
