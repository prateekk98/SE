<?php

return array(
    'url' => Engine_Env::get('WAREHOUSE_URL', 'https://warehouse.socialengine.com'),
    'website_url' => Engine_Env::get('WEBSITE_URL', 'https://www.socialengine.com')
);
