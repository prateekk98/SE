<?php
/**
 * SocialEngine
 *
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: mail.sample.php 9747 2012-07-26 02:08:08Z john $
 */
defined('_ENGINE') or die('Access Denied'); return array(
  'class' => 'Zend_Mail_Transport_Sendmail',
  'args' => array(

  )
) ?>
