<?php
/**
 * SocialEngine
 *
 * @copyright  Copyright 2006-2020 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: general.sample.php 9747 2012-07-26 02:08:08Z john $
 */
defined('_ENGINE') or die('Access Denied'); return array (
  'maintenance' => 
  array (
    'enabled' => false,
    'code' => '',
  ),
  'environment_mode' => 'development',
); ?>
